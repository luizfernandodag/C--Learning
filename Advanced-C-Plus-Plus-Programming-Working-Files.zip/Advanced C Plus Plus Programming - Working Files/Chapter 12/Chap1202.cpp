#include <iostream>
#include <string>

using namespace std;

int main()
{
    string s1 = "clean";
    string s2 = "clear";
    cout << s1.compare(s2) << endl;
    return 0;
}
